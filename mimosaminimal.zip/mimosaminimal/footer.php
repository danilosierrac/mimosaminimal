<div class="footer">
</div><!-- /end .footer-->
</div>  <!-- /end .container -->
<?php wp_footer(); ?>
</body>
</html>