<?php get_header(); ?>

		<h2>page not found, a haiku</h2>

		<div class="post">

			<br />
			<center>
			<h1>our search is lonely</h1>

			<h1>a footprint left in pure snow</h1>

			<h1>blown into <a href="<?php echo get_option('home'); ?>/">nothing</a></h1>
			</center>

		</div> <!-- /end .post -->

	</div>  <!-- /end .container -->

	<?php wp_footer(); ?>

</body>
</html>